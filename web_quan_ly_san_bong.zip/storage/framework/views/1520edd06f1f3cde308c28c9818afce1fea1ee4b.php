<?php $__env->startSection('content'); ?>











    <form id="form_add_field">
        <?php echo csrf_field(); ?>
        <div id="validation-errors"></div>
        <div class="form-group mb-3">
            <label for="simpleinput">Name</label>
            <input type="text" name="name" class="form-control" >
        </div>

        <div class="form-group mb-3">
            <label for="example-email">Phone</label>
            <input type="text" name="phone"  class="form-control" >
        </div>


        <div class="form-group mb-3">
            <label for="example-password">Type</label>
            <select name="type" class="custom-select mb-3">
                    <option value="Sân 7" selected>Sân 7</option>
                    <option value="Sân 11">Sân 11</option>

            </select>
        </div>
        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-group mb-3">
            <label for="example-password">Address</label>
            <input type="text" name="address" class="form-control" >
        </div>
        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-group mb-3">
            <label >Địa chỉ</label>
            <select id="provinces" name="province" class="custom-select mb-3">
                <option disabled selected>Chọn thành phố</option>
                <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($each->id); ?>"><?php echo e($each->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mb-3" id="districts">

        </div>

        <div class="form-group mb-3" id="wards">

        </div>


        <div class="form-group mb-3">
            <label for="example-palaceholder">Size</label>
            <input type="text" name="size" class="form-control" >
        </div>

        <div class="form-group mb-3">
            <label for="example-readonly">Image</label>
            <input type="file" name="image" class="form-control-file" >
        </div>

        <button class="btn btn-info" id="add_field" >Create</button>
    </form>
<script>
    $(document).ready(function (){
        $('#provinces').on('change',function() {
            let provincesId = $(this).val();
            $.ajax({
                url: `/admin/field/create/select/provinces/${provincesId}`,
                method:"get",
                beforeSend: function() {
                    $('#loader').show();
                },
                success: function(res) {
                    $('#districts').html(res);
                },
                complete: function() {
                    $('#loader').hide();
                },
            })
        });
    })
    $('#add_field').on('click',function (e){
        e.preventDefault();
        var form = $('#form_add_field');
        var data = new FormData(form[0]);
        $.ajax({
            url: `/admin/field/create`,
            type: 'POST',
            data: data,
            cache: false,
            processData: false,
            contentType : false,
            success: function (res) {
                alert("success!");

            },
            error: function (xhr) {
                $('#validation-errors').html('');
                $.each(xhr.responseJSON.errors, function(key,value) {
                    $('#validation-errors').append('<div class="alert alert-danger">'+value+'</div');
                });
            }
        });
    })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/field/create_field/create.blade.php ENDPATH**/ ?>