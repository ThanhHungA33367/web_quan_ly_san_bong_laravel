<select name="ward" class="custom-select mb-3" >
    <option disabled selected>Chọn Huyện</option>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($each->id); ?>"><?php echo e($each->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/field/create_field/select_wards.blade.php ENDPATH**/ ?>