<?php $__env->startSection('content'); ?>

    <?php $__env->startPush('custom-scripts'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' type='text/javascript'></script>
    <?php $__env->stopPush(); ?>

        <select id="field" class="custom-select mb-3 col-5">
            <option disabled selected>Chọn sân</option>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($each->id); ?>"><?php echo e($each->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class='card-body'>
            <div id="receive_data1"></div>

        </div>
    <script>
        $(document).ready(function (){
            $('#field').on('change',function() {
                let fieldId = $(this).val();
                $.ajax({
                    url: `/admin/field/calendar/index/${fieldId}`,
                    method:"get",
                    beforeSend: function() {
                        $('#loader').show();
                    },
                    success: function(res) {
                        $("#receive_data1").html(res);
                    },
                    complete: function() {
                        $('#loader').hide();
                    },
                })
            });
        })
        </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/field/calendar_index.blade.php ENDPATH**/ ?>