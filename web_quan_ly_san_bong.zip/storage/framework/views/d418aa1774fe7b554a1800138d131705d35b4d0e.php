<label>
    <select id="districts" name="districts" class="form-control">
        <option selected disabled>Chọn phường</option>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($each->id); ?>"><?php echo e($each->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>

<script>
    $(document).ready(function (){
        $('#districts').on('change',function() {
            let districtsId = $(this).val();

            $.ajax({
                url: `/select/districts/${districtsId}`,
                method:"get",
                beforeSend: function() {
                    $('#loader').show();
                },
                success: function(res) {
                    $('#select_ward').html(res);
                },
                complete: function() {
                    $('#loader').hide();
                },
            })
        });
    })


</script>
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/page/select_districts.blade.php ENDPATH**/ ?>