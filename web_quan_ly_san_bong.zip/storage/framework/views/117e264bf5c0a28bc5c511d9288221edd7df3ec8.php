<label>
    <select id="wards" name="wards" class="form-control">
        <option selected disabled>Chọn phường</option>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($each->id); ?>"><?php echo e($each->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/page/select_wards.blade.php ENDPATH**/ ?>