<?php $__env->startSection('content'); ?>
    abc
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/index.blade.php ENDPATH**/ ?>