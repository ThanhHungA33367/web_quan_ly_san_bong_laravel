<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('custom-scripts'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' type='text/javascript'></script>
    <?php $__env->stopPush(); ?>
    <div class='card'>
        <?php if($errors->any()): ?>
            <div class="card-header">
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>

        <div class='card-body'>
            <form class="float-right form-group form-inline">
                <label class="mr-2">Search:</label>
                <input type="search" name="q" value="<?php echo e($search); ?>" class="form-control">
            </form>

            <table class="table table-striped">
                <tr>
                    <th>#</th>
                    <th>Code Order</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Field Name</th>
                    <th>Date</th>
                    <th>Time start</th>
                    <th>Time end</th>
                    <th>Price</th>
                </tr>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($each->id); ?>

                        </td>
                        <td>
                            <?php echo e($each->code_order); ?>

                        </td>
                        <td>
                            <?php echo e($each->name); ?>

                        </td>
                        <td>
                            <?php echo e($each->phone); ?>

                        </td>
                        <td>
                            <?php echo e($each->fieldname); ?>

                        </td>
                        <td>
                            <?php echo e($each->getDate()); ?>

                        </td>
                        <td>
                            <?php echo e($each->getTimeStart()); ?>

                        </td>
                        <td>
                            <?php echo e($each->getTimeEnd()); ?>

                        </td>
                        <td>
                            <?php echo e($each->price); ?>.000đ
                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>


            <!-- medium modal -->

            <div class="modal" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" >
                            <div id="detail">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <nav>
                <ul class="pagination pagination-rounded mb-0">
                    <?php echo e($data->links()); ?>

                </ul>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/order/approved_order.blade.php ENDPATH**/ ?>