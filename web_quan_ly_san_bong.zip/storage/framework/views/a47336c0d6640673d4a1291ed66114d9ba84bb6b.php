<form  id="form_add_calendar" >
    <?php echo csrf_field(); ?>
    <div class="form-group mb-3"  >
        <label for="simpleinput">Time_start</label>
        <input type="time" step="any" name="time_start" class="form-control" value="<?php echo e($object->getTimeStart()); ?>">
    </div>

    <div class="form-group mb-3">
        <label for="example-email">Time_end</label>
        <input type="time" step="any" name="time_end"  class="form-control" value="<?php echo e($object->getTimeEnd()); ?>">
    </div>
    <input type="hidden" name="id"  class="form-control" value="<?php echo e($object->id); ?>">
    <input type="hidden" name="id_field"  class="form-control" value="<?php echo e($object->id_field); ?>">
    <div class="form-group mb-3">
        <label for="example-password">Price</label>
        <input type="text" name="price" class="form-control" value="<?php echo e($object->price); ?>">
    </div>
    <button class="btn btn-info" id ='update_calendar'>Update</button>

</form>
<script>
    $('#update_calendar').on('click',function (e){
        e.preventDefault();
        var form = $('#form_add_calendar');
        var data = new FormData(form[0]);
        $.ajax({
            url: `/admin/field/calendar/edit/`,
            type: 'POST',
            data: data,
            cache: false,
            processData: false,
            contentType : false,
            success: function (res) {
                alert("success!");
                $("#mediumModal").modal("hide");
                $("#receive_data1").html(res);

            },
            error: function (data) {
                // Android.passParams(url);
            }
        });
    })
</script>
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/field/modal_calendar_edit.blade.php ENDPATH**/ ?>