abababab
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/page/viewww.blade.php ENDPATH**/ ?>