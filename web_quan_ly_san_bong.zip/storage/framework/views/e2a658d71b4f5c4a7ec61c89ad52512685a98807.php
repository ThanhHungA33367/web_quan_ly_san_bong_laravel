
<select id="district" name="district" class="custom-select mb-3" >
    <option disabled selected>Chọn Quận</option>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($each->id); ?>"> <?php echo e($each->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script>
    $(document).ready(function (){
        $('#district').on('change',function() {
            let districtsId = $(this).val();
            $.ajax({
                url: `/admin/field/create/select/districts/${districtsId}`,
                method:"get",
                beforeSend: function() {
                    $('#loader').show();
                },
                success: function(res) {
                    $('#wards').html(res);
                },
                complete: function() {
                    $('#loader').hide();
                },
            })
        });
    })

</script>
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/field/create_field/select_districts.blade.php ENDPATH**/ ?>