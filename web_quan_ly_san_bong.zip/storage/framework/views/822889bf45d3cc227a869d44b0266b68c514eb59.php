<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Starter | Hyper - Responsive Bootstrap 4 Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->


    <!-- App css -->


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="<?php echo e(asset('css/app-creative.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style"/>

    <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('css/app-creative-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">

</head>

<body class="loading" data-layout="topnav" data-layout-config='{"layoutBoxed":false,"darkMode":false,"showRightSidebarOnStart": true}'>

<!-- Begin page -->
<div class="wrapper">
    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->
    <div class="content-page">
        <div class="content">
            <!-- Topbar Start -->
           <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end Topbar -->

            <!-- Start Content-->
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Starter</h4>
                        </div>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
                <!-- end page title -->

            </div>
            <!-- container -->

        </div>
        <!-- content -->
        <!-- Footer Start -->
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end Footer -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->
</div>
<!-- END wrapper -->
<!-- Right Sidebar -->
<?php echo $__env->make('layout.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /Right-bar -->
<!-- bundle -->

<script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
</body>


</html>
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/layout/master.blade.php ENDPATH**/ ?>