<?php $__env->startSection('content'); ?>

        <main style="padding-top: 63px;">
            <div class="container-fluid py-5 px-lg-5">
                <div class="row ">

                    <div class="col">
                        <div class="d-flex justify-content-between align-items-center flex-column flex-md-row mb-5">

                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-marker-id="162" class="col-sm-4 col-xl-3 mb-5">
                                <div class="card h-100 border-0 shadow">
                                    <div style="background-image: url(<?php echo e(asset('/storage/'.$each->image)); ?>); background-size:cover ; height: 200px " class="card-img-top overflow-hidden dark-overlay bg-cover">
                                        <a href="/san-bong-futsal-nguyen-du" class="tile-link"></a>
                                        <div class="card-img-overlay-bottom z-index-20">

                                            <p class="mb-2 text-xs">
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <a href="fdsfds" class="text-lg font-weight-bold"><h4><?php echo e($each->name); ?></h4></a>
                                        <p class="text-sm"><?php echo e($each->address); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Pagination -->
                        <div class="justify-content-center d-flex">

                        </div>
                    </div>
                </div>
            </div>

        </main>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/welcome.blade.php ENDPATH**/ ?>