<?php $__env->startSection('content'); ?>

        <main style="padding-top: 63px;">
            <div class="container-fluid py-5 px-lg-5">
                <div class="row ">

                    <div class="col">
                        <div class="row">
                                <form class="row">
                                    <div>
                                    <label>
                                        <select id="provinces" name="provinces" class="form-control">
                                        <option selected disabled>Chọn tỉnh</option>
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($each->id); ?>"><?php echo e($each->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>
                                    </div>
                            <div id="select_district">
                            </div>
                            <div id="select_ward"> </div>
                            <button class="btn-btn-info">Tìm</button>

                                </form>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div data-marker-id="162" class="col-sm-4 col-xl-3 mb-5">
                                <div class="card h-100 border-0 shadow">
                                    <div style="background-image: url(<?php echo e(asset('/storage/'.$each->image)); ?>); background-size:cover ; height: 200px " class="card-img-top overflow-hidden dark-overlay bg-cover">
                                        <a href="/san-bong-futsal-nguyen-du" class="tile-link"></a>
                                        <div class="card-img-overlay-bottom z-index-20">

                                            <p class="mb-2 text-xs">
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                                <i class="fa fa-star text-muted"></i>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <a href="<?php echo e(route('page.show',$each->id)); ?>" class="text-lg font-weight-bold"><h4><?php echo e($each->name); ?></h4></a>
                                        <p class="text-sm"><?php echo e($each->address); ?></p>
                                        <p class="text-sm"><?php echo e($each->getPriceMin($each->id)); ?>.000đ-<?php echo e($each->getPriceMax($each->id)); ?>.000đ/trận</p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Pagination -->
                        <div class="justify-content-center d-flex">

                        </div>
                    </div>
                </div>
            </div>

        </main>
    <script>
        $(document).ready(function (){
            $('#provinces').on('change',function() {
                let provincesId = $(this).val();
                $.ajax({
                    url: `/select/provinces/${provincesId}`,
                    method:"get",
                    beforeSend: function() {
                        $('#loader').show();
                    },
                    success: function(res) {
                        $('#select_district').html(res);
                    },
                    complete: function() {
                        $('#loader').hide();
                    },
                })
            });
        })
        // function Search_address() {
        //     let provincesId = $('#provinces').val();
        //     let districtsId = $('#districts').val();
        //     let wardsId = $('#wards').val();
        //     if (provincesId !== null || districtsId !== null || wardsId !== null) {
        //         $.ajax({
        //             url: `/`,
        //             method: "get",
        //             data: {
        //                 provincesId: provincesId,
        //                 districtsId: districtsId,
        //                 wardsId: wardsId,
        //             },
        //             beforeSend: function () {
        //                 $('#loader').show();
        //             },
        //             success: function (res) {
        //
        //             },
        //             complete: function () {
        //                 $('#loader').hide();
        //             },
        //         })
        //     }
        //
        // }

    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/page/welcome.blade.php ENDPATH**/ ?>