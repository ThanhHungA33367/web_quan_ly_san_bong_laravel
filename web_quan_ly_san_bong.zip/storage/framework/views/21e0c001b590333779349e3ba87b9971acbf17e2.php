<div id="show">
    <table class="table table-hover table-responsive table-sm">
        <tr>
            <th>Time start:</th>
            <th>Time end:</th>
            <th>Price:</th>
        </tr>
        <?php $__currentLoopData = $object; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($each->getTimeStart()); ?></th>
                <th><?php echo e($each->getTimeEnd()); ?></th>
                <th><?php echo e($each->price); ?></th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


</div>
<?php /**PATH C:\laragon\www\web_quan_ly_san_bong\resources\views/manager/field/create_field_calendar/show_calendar.blade.php ENDPATH**/ ?>