@extends('manager.master')
@section('content')
    abc
@endsection
